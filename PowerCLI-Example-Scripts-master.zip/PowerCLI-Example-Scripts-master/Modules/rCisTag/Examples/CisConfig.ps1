﻿<#
Copyright 2016-2021 VMware, Inc.
SPDX-License-Identifier: BSD-2-Clause
#>

$cisServer = 'vcsa.my.domain'
$cisUser = 'administrator@vsphere.local'
$cisPswd = 'VMware1!'
